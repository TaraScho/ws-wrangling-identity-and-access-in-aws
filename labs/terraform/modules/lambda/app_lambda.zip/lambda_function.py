import os
import json
def handler(event, context):
    # In real code, this would use the secrets to connect to a database
    # NEVER do this - use Secrets Manager instead!
    return {
        'statusCode': 200,
        'body': json.dumps('App running with database connection')
    }
